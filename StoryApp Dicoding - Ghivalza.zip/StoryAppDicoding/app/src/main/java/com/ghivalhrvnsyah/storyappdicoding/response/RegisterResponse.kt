package com.ghivalhrvnsyah.storyappdicoding.response

data class RegisterResponse(
	val error: Boolean? = null,
	val message: String? = null
)

